@extends('client.EN.layout.master')

@section('content')
    @php
        $tr = fn($v) => is_array($v) ? ($v[$locale] ?? ($v['en'] ?? ($v['fa'] ?? ''))) : $v;
    @endphp

    <div class="container-xxl py-5" dir="ltr">
        <div class="container">
            <h2 class="text-center fw-bold mb-5">Gallery Categories</h2>

            <div class="row g-4 justify-content-center">
                @foreach($categories as $cat)
                    <div class="col-6 col-md-4 col-lg-3">
                        <a href="{{ route('clients.gallery_items.category', ['locale' => $locale, 'slug' => $cat->slug])}}"
                           class="text-decoration-none">
                            <div class="card shadow-sm border-0 h-100 text-center">
                                <img src="{{ asset('storage/' . ($cat->cover_image ?? ($cat->galleries->first()->image ?? 'default.jpg'))) }}"
                                     alt="{{ $tr($cat->name) }}"
                                     class="rounded"
                                     style="width:100%; height:220px; object-fit:cover;">
                                <div class="card-body">
                                    <h6 class="fw-bold text-dark">{{ $tr($cat->name) }}</h6>
                                </div>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endsection
