@extends('client.FA.layout.master')

@section('content')
    @php
        $tr = fn($v) => is_array($v) ? ($v[$locale] ?? ($v['fa'] ?? ($v['en'] ?? ''))) : $v;
    @endphp

    <div class="container-xxl py-5" dir="rtl">
        <div class="container">
            <h2 class="fw-bold mb-4 text-center">{{ $tr($category->name) }}</h2>

            <div class="row g-4 justify-content-center">
                @foreach($category->galleries as $item)
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="card border-0 shadow-sm">
                            <img src="{{ asset('storage/'.$item->image) }}"
                                 alt="{{ $tr($item->title) }}"
                                 style="width:100%; height:220px; object-fit:cover;"
                                 class="rounded">
                            <div class="card-body text-center">
                                <h6 class="fw-bold">{{ $tr($item->title) }}</h6>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>

            <div class="text-center mt-4">
                <a href="{{ route('clients.gallery_items.index', ['locale' => $locale]) }}" class="btn btn-outline-primary">
                    بازگشت به دسته‌بندی‌ها
                </a>
            </div>
        </div>
    </div>
@endsection
